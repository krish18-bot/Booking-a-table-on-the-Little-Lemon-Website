import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './App.css';
import BookingForm from './BookingForm';

function App() {
    return (
        <Router>
            <div className="App">
                <nav>
                    <ul>
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/book">Book a Table</Link></li>
                        <li><Link to="/menu">Menu</Link></li>
                        <li><Link to="/contact">Contact</Link></li>
                    </ul>
                </nav>
                <Routes>
                    <Route path="/" element={
                        <div>
                            <h1>Welcome to Little Lemon</h1>
                            <p>Your favorite place for fresh and delicious food!</p>
                        </div>
                    } />
                    <Route path="/book" element={<BookingForm />} />
                    <Route path="/menu" element={
                        <div>
                            <h1>Menu</h1>
                            <p>Explore our delicious menu items!</p>
                        </div>
                    } />
                    <Route path="/contact" element={
                        <div>
                            <h1>Contact Us</h1>
                            <p>Contact us at contact@littlelemon.com.</p>
                        </div>
                    } />
                    <Route path="*" element={
                        <div>
                            <h1>404 - Page Not Found</h1>
                        </div>
                    } />
                </Routes>
            </div>
        </Router>
    );
}

export default App;