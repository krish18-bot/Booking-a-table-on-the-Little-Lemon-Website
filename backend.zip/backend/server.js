const express = require('express');
const cors = require('cors');
const path = require('path');  // Import path for serving static files
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Simulate a database with in-memory data
let bookings = [];

// Serve the homepage
app.get('/', (req, res) => {
    res.send('Welcome to Little Lemon! Visit /menu or /contact for more.');
});

// Route for booking a table
app.post('/api/bookings', (req, res) => {
    const { name, email, date, time } = req.body;
    
    if (!name || !email || !date || !time) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    bookings.push({ name, email, date, time });
    return res.status(201).json({ message: 'Booking successful', booking: { name, email, date, time } });
});

// Route to view all bookings
app.get('/api/bookings', (req, res) => {
    res.status(200).json(bookings);
});

// Additional routes

// Menu Page
app.get('/menu', (req, res) => {
    res.send('<h1>Menu</h1><p>Here you can view our menu items!</p>');
});

// Contact Page
app.get('/contact', (req, res) => {
    res.send('<h1>Contact Us</h1><p>Contact us at contact@littlelemon.com.</p>');
});

// Catch-all route to handle undefined routes
app.get('*', (req, res) => {
    res.status(404).send('Page not found.');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});